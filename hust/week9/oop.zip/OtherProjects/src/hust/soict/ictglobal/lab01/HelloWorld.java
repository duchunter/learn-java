package hust.soict.ictglobal.lab01;

public class HelloWorld {
  public static void main(String[] args) {
    System.out.println("Xin chao \n cac ban!");
    System.out.println("Hello \t world!");
  }
}
