package hust.soict.ictglobal.aims.media;

public interface Playable {
  public void play();
}

