package sort;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;
import javax.swing.Timer;

import test.BouncyBall.BallPitPane.Ball;

import java.util.ArrayList;
import java.util.List;

public class Panel extends JPanel implements ActionListener {
  // Background color
  private static final Color BACKGROUND = Color.WHITE;
  private static int FRAME_PER_SEC = 120;

  public Timer tm = new Timer((int)(1000 / FRAME_PER_SEC), this);
  private List<Column> cols;

  // Init
  public void init() {
  	cols = new ArrayList<Column>(3);

  	while (cols.size() < 2) {
      int x = 4 + (int) (Math.random() * 48);
      Column col = new Column(x, x, x);
//      col.moveVertical(1, 3 * FRAME_PER_SEC);
      col.moveHorizontal(x, 3 * FRAME_PER_SEC);
      cols.add(col);
    }
  }

  // Draw panel
  public void paintComponent(Graphics g) {
//    setBackground(BACKGROUND);
	g.fillRect(0, 0, 600, 600);
	g.setColor(Color.BLACK);
    super.paintComponent(g);
    for (Column col : cols) {
      col.draw(g);
    }

    tm.start();
  }

  // Action
  public void actionPerformed(ActionEvent e) {
    for (Column col : cols) {
      col.move();
      if (col.x >= 600) {
    	 col.moveHorizontal(-1, 3 * FRAME_PER_SEC);
      }
      
      if (col.nextX <= 0) {
    	  col.moveHorizontal(1, 3 * FRAME_PER_SEC);
      }
    }
    repaint();
  }
}


